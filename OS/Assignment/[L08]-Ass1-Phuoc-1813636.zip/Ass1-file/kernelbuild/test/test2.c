#include <get_proc_info.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdint.h>

int main() {
	pid_t mypid = getpid();
	printf("PID: %d\n", mypid);
	struct procinfos info;
	if (get_proc_info(mypid, &info) == 0) {
		printf("Student ID: %ld\n", info.studentID);
		printf("PID of process: %d\n", info.proc.pid);
		printf("Name of process: %s\n", info.proc.name);
		printf("PID of parent process: %d\n", info.parent_proc.pid);
		printf("Name of parent process: %s\n", info.parent_proc.name);
		printf("PID of oldest child process: %d\n", info.oldest_child_proc.pid);
		printf("Name of oldest child process: %s\n", info.oldest_child_proc.name);
	}
	else {
		printf("Cannot get infomation from the process %d\n", mypid);
	}
	return 0;
}
