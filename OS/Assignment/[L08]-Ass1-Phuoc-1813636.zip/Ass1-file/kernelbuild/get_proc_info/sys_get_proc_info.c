#include <linux/kernel.h>
#include <linux/unistd.h>
#include <linux/syscalls.h>
#include <linux/sched.h>
#include <linux/string.h>
#include <linux/uaccess.h>
#include <linux/errno.h>

struct proc_info {
	pid_t pid;
	char name[16];
};

struct procinfos {
	long studentID;
	struct proc_info proc;
	struct proc_info parent_proc;
	struct proc_info oldest_child_proc;
};

SYSCALL_DEFINE2(get_proc_info, pid_t, pid, struct procinfos *, info) {
	struct task_struct *cur_proc = NULL;
	struct task_struct *cur_parent_proc = NULL;
	struct task_struct *cur_oldest_child_proc = NULL;
	void *ChildCheck = NULL;
	struct procinfos *cur_info = (struct procinfos*) kmalloc(sizeof(struct procinfos), GFP_KERNEL);
	
	if(cur_info == NULL) return EINVAL;
	cur_info->studentID = 1813636;
	if(pid == -1) cur_proc = current;
	if(pid == 0) cur_proc = find_task_by_vpid(1)->parent;
	if(pid > 0) cur_proc = find_task_by_vpid(pid);

	if(cur_info == NULL) return EINVAL;
	cur_info->proc.pid = cur_proc->pid;
	strcpy (cur_info->proc.name, cur_proc->comm);
	
	cur_parent_proc = cur_proc->parent;
	if(cur_parent_proc == NULL) return EINVAL;
	cur_info->parent_proc.pid = cur_parent_proc->pid;
	strcpy(cur_info->parent_proc.name, cur_parent_proc->comm);

	ChildCheck = list_first_entry_or_null(&cur_proc->children, struct task_struct, sibling);
	if(ChildCheck == NULL){
		cur_info->oldest_child_proc.pid = (pid_t) -1;
		strcpy(cur_info->oldest_child_proc.name, "Cannot find");
	}
	else{
		cur_oldest_child_proc = list_first_entry(&cur_proc->children, struct task_struct, sibling);
		if(cur_oldest_child_proc == NULL) return EINVAL;
		cur_info->oldest_child_proc.pid = cur_oldest_child_proc->pid;
		strcpy(cur_info->oldest_child_proc.name, cur_oldest_child_proc->comm);
	}
	copy_to_user(info, cur_info, sizeof(struct procinfos));
	kfree (cur_info);
	return 0;
}

