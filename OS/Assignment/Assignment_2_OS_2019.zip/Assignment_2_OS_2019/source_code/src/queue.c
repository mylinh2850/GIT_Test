#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int empty(struct queue_t * q) {
	return (q->size == 0);
}

void enqueue(struct queue_t * q, struct pcb_t * proc) {
	/* TODO: put a new process to queue [q] */
	if (q->size == MAX_QUEUE_SIZE) return;
	q->proc[q->size] = proc;
	q->size += 1;
}

struct pcb_t * dequeue(struct queue_t * q) {
	/* TODO: return a pcb whose prioprity is the highest
	 * in the queue [q] and remember to remove it from q
	 * */
	if (q->size == 0)return NULL;
	struct pcb_t * result;
	int pos=0;
	for (int j=1;j<q->size;j++){
		if (q->proc[pos]->priority<q->proc[j]->priority){
			pos=j;
		}
	}
	result = q->proc[pos];
	q->size -= 1;
	for (int d=pos;d<q->size;d++){
		q->proc[d]=q->proc[d+1];
	}
	return result;
}

