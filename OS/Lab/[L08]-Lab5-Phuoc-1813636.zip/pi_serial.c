#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
int main(int argc, char *argv[]){
	clock_t start, end;
	double time_taken;
	if(argc != 2) {
		fprintf(stderr,"usage: a.out_<interger_value>\n");
		return -1;
	}
	if (atoi(argv[1]) < 0){
		fprintf(stderr, "%d must >= 0\n",atoi(argv[1]));
		return -1;
	}
	start = clock();
	int i;
	int in_Circle = 0, out_Circle = 0;
	srand(time(0));
	for (i = 0; i < atoi(argv[1]); i++){
		double x = 2*(rand()/((double)(RAND_MAX))) - 1;
		double y = 2*(rand()/((double)(RAND_MAX))) - 1;
		double R = sqrt((double)x*x + y*y);
		if (R <= 1) in_Circle++;
		else out_Circle++;
	}
	double pi = (double)(4 * in_Circle) / (in_Circle + out_Circle);
	printf("pi = %f\n",pi);
	end = clock();
	time_taken = ((double)(end-start))/CLOCKS_PER_SEC;
	printf("Execution time using pi_serial: %f\n", time_taken);
	return 0;
}
