#include <stdio.h>
#include <stdlib.h>
#include "factorial.h"
#include "readline.h"

int main (int argc, char* argv[]){
	char *str = (char*)malloc(50*sizeof(char));
	char* result;
	int i;
	if((i = read_line(str)) == 0){
		printf("-1\n");
	}
	else{
		int number = atoi(str);
		char* array = factorial(number);
		result = (char*)malloc(sizeof(array));
		int j = 0;
		while(array[j] != '\0'){
			result[j] = array[j];
			j++;
		}
		result[j] = '\0';
		printf("%s\n", result);
	}
	return 0;	
}
