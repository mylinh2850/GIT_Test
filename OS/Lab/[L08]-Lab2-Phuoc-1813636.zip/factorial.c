#include "factorial.h"
#include <stdio.h>
#include <stdlib.h>

long int fact(int n){
	if(n == 0||n == 1) return 1;
	return n * fact(n-1);
}
char* factorial(const int aNumber){
	long int number = fact(aNumber);
	char array[100];
	sprintf(array, "%ld", number);
	char* p = (char*)malloc(sizeof(array));
	int i = 0;
	while (array[i] != '\0'){
		p[i] = array[i];
		i++;
	}
	array[i] = '\0';
	return p;
}
