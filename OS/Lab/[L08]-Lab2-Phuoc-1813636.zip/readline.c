#include "readline.h"
#include <stdio.h>
#include <stdlib.h>

int read_line(char *str){
	scanf("%s", str);	
	int i = 0;
	while(str[i] >= '0' && str[i] <= '9' && str[i] != '\0'){
		i++;
	}
	if (str[i] == '\0') return 1;
	return 0;
}
