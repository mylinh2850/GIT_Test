#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <pthread.h>
#define NUM_THREADS 8

int in_Circle = 0, out_Circle = 0;
void *runner(void* param);
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
int main(int argc, char* argv[]){
	if(argc != 2){
		fprintf(stderr, "usage: a.out <integer value>\n");
		return -1;
	}
	if(atoi(argv[1]) < 0){
		fprintf(stderr, "%d must >= 0\n", atoi(argv[1]));
		return -1;
	}
	int i;
	pthread_t threads[NUM_THREADS];
	for(i = 0; i < NUM_THREADS; i++){
		pthread_create(&threads[i], NULL, runner, argv[1]);
	}
	for(i = 0; i < NUM_THREADS; i++){
		pthread_join(threads[i], NULL);
	}		
	//printf("%d %d\n", in_Circle, out_Circle);
	double pi = (double)(4 * in_Circle)/(in_Circle + out_Circle);
	printf("pi = %f\n", pi);
	pthread_exit(NULL);
	return 0;
}
void *runner(void *param){
	int nPoint = atoi(param)/NUM_THREADS;
	unsigned int rand_s = rand();
	int j;	
	srand(time(0));
	for(j = 0; j < nPoint; j++){
		double x = 2*((rand_r(&rand_s))/((double)(RAND_MAX))) - 1;
		double y = 2*((rand_r(&rand_s))/((double)(RAND_MAX))) - 1;
		double R = sqrt(x*x + y*y);
		pthread_mutex_lock(&lock);
		if(R <= 1) in_Circle++;
		else out_Circle++;
		pthread_mutex_unlock(&lock);
	}
	pthread_exit(NULL);
}

