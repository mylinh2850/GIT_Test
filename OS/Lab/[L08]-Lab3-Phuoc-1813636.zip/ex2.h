#ifndef EX2_H
#define EX2_H

#endif
