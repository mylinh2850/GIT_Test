#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "ex2.h"

int main(){
	if(fork() > 0){ //Create B
		//This is A
		if(fork() > 0){ //Create C
			//This is A
			fork(); //Create D	
		}
		else{
			//This is C
			if(fork() == 0){ //Create G
				fork(); //Create I
			}
		}
	}	
	else {
		//This is B
		if(fork() > 0){ //Create E
			//This is B
			fork(); //Create F
		}
	}
	return 0;		
}
