#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "ex1.h"
#define MAX_LETTER 79

int main(){
	char line[MAX_LETTER];
	int count = 0;
	int* number;
	char c;
	FILE *temp_file = fopen("numbers.txt","r");
	for(c = getc(temp_file); c != EOF; c = getc(temp_file)){
		if(c == '\n') count++;
	}
	number = (int*)malloc(sizeof(int)*count);
	fclose(temp_file);
	
	FILE* file = fopen("numbers.txt","r");
	int i = 0;
	while(fgets (line, MAX_LETTER, file) != NULL){
		number[i++] = atoi(line);
	}
	fclose(file);
	int div2 = 0, div3 = 0, div5 = 0;
	if(fork() > 0){
		wait();
		for(i = 0; i < count; i++){
			if((number[i]) % 5 == 0) div5++;
		}
		printf("%d\n", div5);
	}
	else{
		if(fork() > 0){
			wait();
			for(i = 0; i < count; i++){
				if((number[i]) % 3 == 0) div3++;
			}
			printf("%d\n", div3);
		}
		else{
			for(i = 0; i < count; i++){
				if((number[i]) % 2 == 0) div2++;
			}
			printf("%d\n", div2);
		}
	}
	free(number); 
	return 0;
}
