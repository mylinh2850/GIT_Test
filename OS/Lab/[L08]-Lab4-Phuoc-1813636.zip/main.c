#include <stdio.h>
#include <stdlib.h>
#include "ex1.h"

int main(){
	int* ptr = aligned_malloc(16,64);
	printf("ptr addr: %p\n", ptr);
	aligned_free(ptr);
	return 0;
}
