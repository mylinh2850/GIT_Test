#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ex1.h"
void* aligned_malloc(unsigned int size, unsigned int align){
	if (size == 0) return NULL;
	void* ptr;
	void** ptr2;
	int offset = align - 1 + sizeof(void*);
	if((ptr = (void*)malloc(size + offset)) == NULL) return NULL;
	ptr2 = (void**)(((size_t)(ptr) + offset) & ~(align - 1));
	ptr2[-1] = ptr;
	return ptr2;
}
void aligned_free (void* ptr){
	free(((void**)ptr)[-1]);
}
